class AppConstants {
  static const String baseUrl = "http://localhost:5000";
}
